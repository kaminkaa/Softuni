package entities.items;

public class Laptop extends BaseItem {

    public Laptop() {
        super(3000);
    }
}
