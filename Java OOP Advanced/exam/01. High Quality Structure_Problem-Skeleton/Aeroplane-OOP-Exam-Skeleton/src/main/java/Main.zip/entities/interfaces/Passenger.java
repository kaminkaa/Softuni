package entities.interfaces;
import java.util.List;

public interface Passenger {
    String getUsername();

    List<Bag> getBags();
}
