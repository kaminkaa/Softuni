package entities.items;

public class CellPhone extends BaseItem {

    public CellPhone() {
        super(700);
    }
}
