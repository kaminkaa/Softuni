package entities.airplanes;

public class LightAirplane extends Airplane {
    public LightAirplane() {
        super(5, 8);
    }
}
