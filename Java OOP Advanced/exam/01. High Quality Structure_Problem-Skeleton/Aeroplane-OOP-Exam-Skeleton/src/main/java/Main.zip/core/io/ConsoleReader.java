package core.io;

import core.io.interfacese.Reader;
import java.io.IOException;

public class ConsoleReader implements Reader {

    @Override
    public String readLine() throws IOException {
        return null;
    }
}
