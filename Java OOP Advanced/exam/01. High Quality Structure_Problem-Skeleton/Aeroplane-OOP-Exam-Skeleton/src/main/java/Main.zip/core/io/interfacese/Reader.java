package core.io.interfacese;
import java.io.IOException;

public interface Reader {
    String readLine() throws IOException;
}
