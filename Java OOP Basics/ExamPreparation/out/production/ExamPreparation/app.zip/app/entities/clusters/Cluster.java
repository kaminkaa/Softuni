package app.entities.clusters;

import app.entities.cells.Cell;

public class Cluster {
    private String id;
    private int rows;
    private int cols;
    private Cell[][] cells;

    public Cluster(String id, int rows, int cols) {
        this.id = id;
        this.rows = rows;
        this.cols = cols;
        this.cells = new Cell[rows][cols];
    }

    public String getId() {
        return id;
    }

    public int getRows() {
        return rows;
    }

    public int getCols() {
        return cols;
    }

    public Cell[][] getCells() {
        return cells;
    }

    public boolean addCell(Cell cell) {
        if (cell.getPositionRow() > this.getRows()-1 || cell.getPositionCol() > this.getCols()-1) {
            return false;
        }
        this.cells[cell.getPositionRow()][cell.getPositionCol()] = cell;
        return true;
    }

    private int getCellsCount() {
        int count = 0;

        for (Cell[] cells : this.cells) {
            for (Cell cell : cells) {
                if (cell != null) {
                    count++;
                }
            }
        }

        return count;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("\n----Cluster %s\n", this.getId()));
        if (this.getCellsCount() > 0) {
            for (Cell[] cell : this.cells) {
                for (Cell cell1 : cell) {
                    if (cell1 != null) {
                        sb.append(cell1.toString());
                    }
                }
            }
        }
        return sb.toString();
    }
}
