package app.io;

public class ConsoleWriter {

    public void writeLine(String line) {
        System.out.println(line);
    }
}
