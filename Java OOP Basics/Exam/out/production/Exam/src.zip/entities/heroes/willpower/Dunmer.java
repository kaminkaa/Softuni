package entities.heroes.willpower;

public class Dunmer extends Willpower {

    public Dunmer(String name, int magicka, int fatigue, int health) {
        super(name, magicka, fatigue, health, "DUNMER");
    }
}
