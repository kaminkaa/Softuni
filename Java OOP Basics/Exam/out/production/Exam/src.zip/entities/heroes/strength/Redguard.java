package entities.heroes.strength;

public class Redguard extends Strength {

    public Redguard(String name, int magicka, int fatigue, int health) {
        super(name, magicka, fatigue, health, "REDGUARD");
    }
}
